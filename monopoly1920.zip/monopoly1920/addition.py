# In gameboard.py
def _load_game_board(self, csv_path):
    """Enhanced function to load and return the game board from a file
       with more robust error handling and logging
    """
    properties = []
    try:
        with open(csv_path, "r") as f:
            # Add error handling for file not found
            if not os.path.exists(csv_path):
                raise FileNotFoundError(f"Board configuration file not found: {csv_path}")

            # Skip header, validate columns
            header = next(f).strip().split(',')
            expected_columns = ["name", "space", "color", "position", "price", "build", "rent"]
            if not all(col in header for col in expected_columns):
                raise ValueError("Invalid CSV format. Missing required columns.")

            for line in f:
                line = line.strip()
                data = line.split(",")

                # Validate data integrity
                if len(data) < len(self.__boardCSV):
                    print(f"Skipping invalid board entry: {line}")
                    continue

                # More robust property creation
                try:
                    utility = data[self.__boardCSV["space"]] == "Utility"
                    railroad = data[self.__boardCSV["space"]] == "Railroad"
                    
                    sq = gamesquare.GameSquare(
                        name=data[self.__boardCSV["name"]], 
                        price=int(data[self.__boardCSV["price"]]) if data[self.__boardCSV["price"]] else 0,
                        rent=int(data[self.__boardCSV["rent"]]) if data[self.__boardCSV["rent"]] else 0, 
                        color=data[self.__boardCSV["color"]],
                        is_utility=utility, 
                        is_railroad=railroad, 
                        space=data[self.__boardCSV["space"]]
                    )
                    properties.append(sq)
                except (ValueError, IndexError) as e:
                    print(f"Error processing board entry: {e}")

        # Validate board size
        if len(properties) != 40:
            print(f"Warning: Board has {len(properties)} squares instead of the standard 40.")

        return properties

    except (IOError, FileNotFoundError) as e:
        print(f"Error loading board configuration: {e}")
        # Fallback to a default board configuration
        return self._create_default_board()

def _create_default_board(self):
    """Create a default board configuration if CSV loading fails"""
    default_properties = [
        gamesquare.GameSquare(name="GO", price=0, rent=0, color=None, is_utility=False, is_railroad=False, space="Special"),
        # Add more default squares as needed
    ]
    return default_properties

# In controller.py
def setup_game(self):
    """Enhanced game setup with more robust player creation"""
    players = []
    while True:
        try:
            num_players = int(input("How many players? (2-8 players): "))
            if 2 <= num_players <= 8:
                break
            else:
                print("Please enter a number between 2 and 8.")
        except ValueError:
            print("Invalid input. Please enter a number.")

    for i in range(num_players):
        while True:
            username = input(f"Player {i + 1}, enter your username (3-10 characters): ").strip()
            if 3 <= len(username) <= 10:
                # Check for duplicate names
                if username not in [p.name for p in players]:
                    player = plr.Player(username, 1500)
                    players.append(player)
                    break
                else:
                    print("Username already taken. Choose a different name.")
            else:
                print("Username must be between 3 and 10 characters.")

    return players

# In view.py, add a method to display initial game setup
def display_game_setup_instructions(self):
    """Display game setup instructions in the GUI"""
    setup_text = """
    Monopoly 1920 Game Setup
    -----------------------
    1. Enter the number of players (2-8)
    2. Choose unique usernames for each player
    3. Start the game and have fun!
    
    Game Rules:
    - Each player starts with $1500
    - Roll dice to move around the board
    - Buy properties, collect rent
    - Avoid going bankrupt!
    """
    self.text_box.insert(tk.END, setup_text)