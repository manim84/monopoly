let currentSquare = 0;  // Example: Current position of the player
function updateBoardImage() {
    fetch('/board_images')
        .then(response => response.json())
        .then(data => {
            if (data.images.length > currentSquare) {
                document.getElementById("boardSquareImage").src = data.images[currentSquare];
            }
        });
}

        updateBoardImage(); // Call on page load

// Example: Simulate moving to a new square
function movePlayer() {
    currentSquare = (currentSquare + 1) % 40;  // Move to the next square
    updateBoardImage();
    }
function actionTaken(action){
    let messageBox = document.getElementById("messageBox");
    switch(action){
        case "roll":
            messageBox.innerText = "You rolled the dice";
            break
        case 'purchase':
            messageBox.innerText = "You purchased a property!";
            break;
        case 'mortgage':
            messageBox.innerText = "You mortgaged a property.";
            break;
        case 'unmortgage':
            messageBox.innerText = "You unmortgaged a property.";
            break;
        case 'bankrupt':
            messageBox.innerText = "You went bankrupt!";
            break;
        case 'end_turn':
            messageBox.innerText = "You ended your turn.";
            break;
        default:
            messageBox.innerText = "Unknown action.";
    }
}