from flask import Flask, render_template, jsonify, request
import os
import controller
import observer

app = Flask(__name__)

app.config['STATIC_FOLDER'] = 'static'

@app.route('/')
def home():
    return render_template('page2.html')  # Corrected the file path

@app.route('/action' , methods = ['POST'])
def game_action():
    action = request.json.get('action')

    if action == "roll":
        observer.Event("roll", None)
    elif action == "purchase":
        observer.Event("purchase", None)
    elif action == "mortgage":
        observer.Event("mortgage", None)
    elif action == "unmortgage":
        observer.Event("unmortgage", None)
    elif action == "end_turn":
        observer.Event("end_turn", None)

    return jsonify({"status": "success", "action": action})

@app.route('/game_state')
def game_state():
    return jsonify({"status": "Game Starts here"})

@app.route('/board_images')
def get_board_images():
    """Return a list of all board square image paths"""
    square_images = [f"/static/images/properties/{i}.png" for i in range(40)]
    return jsonify({"images": square_images})

if __name__ == '__main__':
    app.run(debug=True)
